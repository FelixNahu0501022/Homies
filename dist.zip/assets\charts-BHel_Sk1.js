import"./vendor-CN57f8Bo.js";

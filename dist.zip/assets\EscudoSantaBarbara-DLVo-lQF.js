const a="/assets/EscudoSantaBarbara-hfVIH-l9.jpg";export{a as e};
